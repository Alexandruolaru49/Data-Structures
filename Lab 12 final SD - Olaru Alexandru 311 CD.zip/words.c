#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef char* Key;
typedef int Value;
typedef long(*HashFunction)(Key, long);

typedef struct Element {
  Key key;
  Value value;
  struct Element *next;
} Element;

typedef struct HashTable {
  Element** elements;
  long size;
  HashFunction hashFunction;
} HashTable;

void initHashTable(HashTable **h, long size, HashFunction f) {
  // Cerinta 1
  int i ;
  (*h) = malloc(sizeof(HashTable));
  (*h)->size = size;
  (*h)->hashFunction = f;
  (*h)->elements = malloc(size * sizeof(Element*));
  for(i = 0 ; i < size ; i++) {
    (*h)->elements[i] = NULL;
  } 
}

int exists(HashTable *hashTable, Key key) {
  // Cerinta 1
  long i = hashTable->hashFunction(key, hashTable->size);
  Element *index;
  index = hashTable->elements[i];
  while(index != NULL) {
    if(strcmp(key, index->key) == 0) {
      return 1;
    }
    index = index->next;
  }
  return 0;
}

Value get(HashTable *hashTable, Key key) {
  // Cerinta 1
  long i = hashTable->hashFunction(key, hashTable->size);
  Element *index;
  index = hashTable->elements[i];
  while(index != NULL) {
    if(strcmp(key, index->key) == 0) {
      return index->value;
    }
    index = index->next;
  }
  return 0;
}

void put(HashTable *hashTable, Key key, Value value) {
  // Cerinta 1
  long i = hashTable->hashFunction(key, hashTable->size);
  Element *index;
  index = hashTable->elements[i];
  while(index != NULL) {
    if(strcmp(key, index->key) == 0){
    index->value = value;
    return ;
    }
    index = index->next;
  }
  index = malloc(sizeof(Element));
  index->key = strdup(key);
  index->value = value;
  index->next = hashTable->elements[i];
  hashTable->elements[i] = index;
}

void deleteKey(HashTable *hashTable, Key key) {
  // Cerinta 1
  if(exists(hashTable, key) == 0) {
    return;
  }
  HashFunction f = hashTable->hashFunction;
  long i = f(key, hashTable->size);
  Element *p, *c;
  p = hashTable->elements[i];
  c = p->next;
  if(c == NULL) {
    free(p->key);
    free(p);
    hashTable->elements[i] = NULL;
  }
  while(c != NULL) {
    if(strcmp(c->key, key) == 0){
      p->next = c->next;
      free(c->key);
      free(c);
      break;
    }
    p = c;
    c = c->next;
  }
}

void print(HashTable *hashTable) {
  // Cerinta 1
  long i;
  Element *index;
  for(i = 0 ; i < hashTable->size ; i++) {
    index = hashTable->elements[i];
    printf("index: %ld\n", i);
    while(index != NULL) {
      printf("%s:%d", index->key, index->value);
      index = index->next;
    }
    printf("\n");
  } 
}

void freeHashTable(HashTable *hashTable) {
  // Cerinta 1
  Element *aux1, *aux2;
  long i;
  for(i = 0 ; i < hashTable->size ; i++) {
    aux1 = hashTable->elements[i];
    aux2 = NULL;
    while(aux1) {
      aux2 = aux1;
      aux1 = aux1->next;
      free(aux2->key);
      free(aux2);
    }
  }
  free(hashTable->elements);
  free(hashTable);
  
}


long hash1(Key word, long size) {
  // Cerinta 2
  long i = 0;
  long h = 0;
  while(word[i] != '\0') {
    h = word[i] +  17 * h;
    i++;
  }
  return h % size;
}

int main(int argc, char* argv[]) {
  HashTable *hashTable;
  FILE *f1, *f2;
  char word[256];
  long hashSize, common;

  hashSize = atoi(argv[1]);
  f1 = fopen(argv[2], "r");
  f2 = fopen(argv[3], "r");

  initHashTable(&hashTable, hashSize, &hash1);

  // Cerinta 3

  while(fscanf(f1, "%s", word) != EOF) {
    if(exists(hashTable, word) != 0) {
      put(hashTable, word, get(hashTable, word) + 1);
    }
    else {
      put(hashTable, word, 1);
    }
  }
  print(hashTable);
  // Cerinta 4
  HashTable *hash2;
  Value nr;
  Element *first;
  long comun = 0, k, i;
  initHashTable(&hash2, hashSize, &hash1);
  while(fscanf(f2, "%s", word) != EOF) {
    if(exists(hashTable, word) != 0) {
      nr = get(hash2, word);
      put(hash2, word, nr + 1);
    }
    else {
      put(hash2, word, 1);
    }
  }
  for(i = 0 ; i < hash2->size ; i++) {
    first = hash2->elements[i];
    while(first != NULL) {
      if(exists(hashTable, first->key) != 0) {
        k = get(hashTable, first->key);
        if(k < first->value) {
          comun = comun + k;
        }
        else {
          comun = comun + first->value;
        }
      }
      first = first->next;
    }
  }


  printf("Common words: %ld\n", comun);

  fclose(f1);
  fclose(f2);
  return 0;
}
