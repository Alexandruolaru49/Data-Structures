#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include "heap.h"

typedef int TCost;

typedef struct node
{
	int v;
	TCost c;
	struct node *next;
} TNode, *ATNode;

typedef struct
{
	int nn;
	ATNode *adl;
}	TGraphL;


void alloc_list(TGraphL * G, int n)
{
    int i;
    G->nn = n;
	G->adl = (ATNode*) malloc((n+1)*sizeof(ATNode));
	for(i = 0; i < n; i++)
		G->adl[i] = NULL;

}

void free_list(TGraphL *G)
{
    int i;
    ATNode it;
    for(i = 1; i < G->nn; i++){
		it = G->adl[i];
		while(it != NULL){
			ATNode aux = it;
			it = it->next;
			free(aux);
		}
		G->adl[i] = NULL;
	}
	G->nn = 0;
}

void insert_edge_list(TGraphL *G, int v1, int v2, int c)
{
 TNode *t;
 t=(ATNode)malloc(sizeof(TNode));
 t->v = v2; t->c=c; t->next = G->adl[v1]; G->adl[v1]=t;
 t=(ATNode)malloc(sizeof(TNode));
 t->v = v1;  t->c=c; t->next = G->adl[v2]; G->adl[v2]=t;
}


void dijkstra(TGraphL G, int s)
{
    int v, i;
	int noduri = G.nn;
	int d[100];
	MinHeap *h = newQueue(noduri);
	for(i = 0 ; i < noduri ; i++) {
		d[i] = INT_MAX;
		h->elem[i] = newNode(i, d[i]);
		h->pos[i] = i;
	}
	h->size = noduri;
	h->elem[s] = newNode(s, d[s]);
	h->pos[s] = s;
	d[s] = 0;
	SiftUp(h, s, d[s]);
	while(isEmpty(h) == 0) {
		MinHeapNode *node = removeMin(h);
		int u;
		u = node->v;
		TNode *t = G.adl[u];
		while(t) {
			v = t->v;
			if(isInMinHeap(h, v) && (d[u] != INT_MAX) && (d[v] > d[u] + t->c)) {
				d[v] = d[u] + t->c;
				SiftUp(h, v, d[v]);
			}
			t = t->next;
		}
	}
	printf("Afisare Algoritm Dijkstra:\n");
	for(i = 0 ; i < noduri ; i++) {
		printf("varf: %d     drum minim: %d\n",i, d[i]);
	}
	printf("\n\n");

}

void Prim(TGraphL G)
{
	int v, i;
	int noduri = G.nn;
	int d[100], parinte[100];
	MinHeap *h = newQueue(noduri);
	for(i = 0; i < noduri ; i++) {
		d[i] = INT_MAX;
		parinte[i] = -1;
		h->elem[i] = newNode(i, d[i]);
		h->pos[i] = i;
	}
	h->size = noduri;
	h->elem[0] = newNode(0, d[0]);
	d[0] = 0;
	h->pos[0] = 0;
	while(isEmpty(h) == 0) {
		MinHeapNode *node = removeMin(h);
		int u;
		u = node->v;
		TNode *t = G.adl[u];
		while(t) {
			v = t->v;
			if(isInMinHeap(h, v) && (d[v] > t->c)) {
				d[v] = t->c;
				parinte[v] = u;
				SiftUp(h, v, d[v]);
			}
			t = t->next;
		}
	}
	printf("Afisare Algoritm Prim:\n");
	for(i = 1 ; i < noduri ; i++) {
		printf("parinte: %d     varf: %d\n",parinte[i], i);
	}
	printf("\n\n");
    
}


int main()
{
    int i,v1,v2,c;
	int V,E;
	TGraphL G;
	ATNode t;
	freopen ("graph.in", "r", stdin);
	scanf ("%d %d", &V, &E);
	alloc_list(&G, V);

	for (i=1; i<=E; i++)
	{
		scanf("%d %d %d", &v1, &v2, &c);
	    insert_edge_list(&G, v1,v2, c);
	}

	for(i=0;i<G.nn;i++)
	{
    	printf("%d : ", i);
    	for(t = G.adl[i]; t != NULL; t = t->next)
   			 printf("%d ",t->v);
    		 printf("\n");
	}
	dijkstra(G,0);
	Prim(G);

	return 0;
}