#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "Util.h"
#include "Graph.h"

TGraphL* createGraphAdjList(int numberOfNodes) {
	//TODO: 1
	TGraphL *graph = malloc(sizeof(TGraphL));
	graph->adl = NULL;
	graph->nn = numberOfNodes;
	graph->adl = malloc(graph->nn * sizeof(ATNode));
	int i;
	for(i = 0; i < numberOfNodes; i++) {
		graph->adl[i] = NULL;
	}
	return graph;
}

void addEdgeList(TGraphL* graph, int v1, int v2) {
	//TODO: 1
	ATNode NewNode1 = NULL, NewNode2 = NULL;
	NewNode1 = malloc(sizeof(TNode));
	NewNode1->c = 1;
	NewNode1->next = NULL;
	NewNode1->v = v2;

	if(graph->adl[v1] == NULL) {
		graph->adl[v1] = NewNode1;
	}
	else {
		NewNode1->next = graph->adl[v1];
		graph->adl[v1] = NewNode1;
	}

	NewNode2 = malloc(sizeof(TNode));
	NewNode2->c = 1;
	NewNode2->next = NULL;
	NewNode2->v = v1;

	if(graph->adl[v2] == NULL) {
		graph->adl[v2] = NewNode2;
	}
	else {
		NewNode2->next = graph->adl[v2];
		graph->adl[v2] = NewNode2;
	}
}

List* dfsIterative(TGraphL* graph, int s) {

	//TODO: 2
	Stack *stack = createStack();
	List *path = createList();
	int *visited = calloc(graph->nn, sizeof(int));
	push(stack, s);
	visited[s]++;
	int nod;
	ATNode aux;

	while(!isStackEmpty(stack)) {
		nod = top(stack);
		pop(stack);
		push(path, nod);

		aux = graph->adl[nod];
		while(aux != NULL) {
			if(visited[aux->v] == 0) {
				push(stack, aux->v);
				visited[aux->v]++;
			}
			aux = aux->next;
		}
	}
	free(visited);
	destroyStack(stack);
	return path;
}

void dfsRecHelper(TGraphL* graph, int* visited, List* path, int s) {
	//TODO: 3
	visited[s]++;
	push(path, s);
	ATNode aux = graph->adl[s];
	while(aux != NULL) {
		if(visited[aux->v] == 0) {
			dfsRecHelper(graph, visited, path, aux->v);
		}
		aux = aux->next;
	}
}

List* dfsRecursive(TGraphL* graph, int s) {
	// TODO 3
	int *visited = calloc(graph->nn , sizeof(int));
	List *path = createList();
	dfsRecHelper(graph, visited, path, s);
	free(visited);
	return path;
}

List* bfs(TGraphL* graph, int s){
	// TODO: 4
	int *visited = calloc(graph->nn, sizeof(int));
	Queue *q = createQueue();
	List *path = createList();
	enqueue(q, s);
	visited[s]++;
	int nod;
	ATNode aux;
	while(!isQueueEmpty(q)) {
		nod = front(q);
		dequeue(q);
		push(path, nod);

		aux = graph->adl[nod];
		while(aux != NULL) {
			if(visited[aux->v] == 0) {
				enqueue(q, aux->v);
				visited[aux->v]++;
			}
			aux = aux->next;
		}
	}
	destroyQueue(q);
	free(visited);
	return path;
}


void destroyGraphAdjList(TGraphL* graph){
	// TODO: 5
	ATNode aux, k;
	int i ;
	for(i = 0 ; i < graph->nn ; i++) {
		aux = graph->adl[i];
		
		while(aux != NULL) {
			k = aux;
			aux = aux->next;
			free(k);
		}
		
	}
	free(graph->adl);
	free(graph);
}

void removeEdgeList(TGraphL* graph, int v1, int v2){
	TNode* it = graph->adl[v1];
	TNode* prev = NULL;
	while(it != NULL && it->v != v2){
		prev = it;
		it = it->next;
	}

	if(it == NULL)return;

	if(prev != NULL)
		prev->next = it->next;
	else
		graph->adl[v1] = it->next;
	free(it);

	it = graph->adl[v2];
	prev = NULL;
	while(it != NULL && it->v != v1){
		prev = it;
		it = it->next;
	}
	if(it == NULL) return;
	if(prev != NULL)
		prev->next = it->next;
	else
		graph->adl[v2] = it->next;

	free(it);
}

void removeNodeList(TGraphL* graph, int v){
	for(int i = 0; i < graph->nn;i++){
		removeEdgeList(graph,v,i);
	}
}
