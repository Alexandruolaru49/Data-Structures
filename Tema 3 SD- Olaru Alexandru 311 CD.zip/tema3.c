#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_STR_LEN 11

typedef struct TNode {
    char v[MAX_STR_LEN]; // numele nodului
    int index; 
    struct Tnode *next;
}TNode, *ATNode;

typedef struct {
    int n; // nr de noduri
    int m; // nr de arce
    ATNode *adl;
}TGraphL;

TGraphL* createGraphAdjList(int nr_noduri, int nr_arce) {
	//TODO: 1
	TGraphL *graph = malloc(sizeof(TGraphL));
	graph->adl = NULL;
	graph->n = nr_noduri;
    graph->m = nr_arce;
	graph->adl = malloc(graph->n * sizeof(ATNode));
	int i;
	for(i = 0; i < nr_noduri; i++) {
		graph->adl[i] = NULL;
	}
	return graph;
}

int Ciclic_aux(TGraphL *graph, int idx, int *visited1, int *visited2) {
    ATNode i;
    if(visited1[idx] == 0) {
        visited1[idx]++;
        visited2[idx]++;
        i = graph->adl[idx];
        while(i != NULL) {
            if((visited1[i->index] == 0) && (Ciclic_aux(graph, i->index, visited1, visited2) == 1)) {
                return 1;
            }
            else {
                if(visited2[i->index] != 0) {
                    return 1;
                }
            }
            i = i->next;
        }
    }
    visited2[idx] = 0;
    return 0;
}

int Ciclic(TGraphL *graph) {
    int *visited1, *visited2, i;
    visited1 = calloc(graph->n, sizeof(int));
    visited2 = calloc(graph->n, sizeof(int));
    for(i = 0; i < graph->n; i++) {
        if(Ciclic_aux(graph, i, visited1, visited2) != 0) {
            free(visited1);
            free(visited2);
            return 1;   // graful este ciclic
        }
    }
    free(visited1);
    free(visited2);
    return 0;           // graful este aciclic
}



int main(int argc, char *argv[]) {

    FILE *f_in, *f_out;
    f_in = fopen("bnet.in","r");
    f_out = fopen("bnet.out", "w");
    int nr_noduri, nr_arce, i, j;
    char noduri[MAX_STR_LEN] = "\0", s1[MAX_STR_LEN], s2[MAX_STR_LEN];
    ATNode aux, prev;


    fscanf(f_in, "%d %d\n", &nr_noduri, &nr_arce);
    TGraphL *graph = createGraphAdjList(nr_noduri, nr_arce);
    
    //Citesc fiecare nod pentru a-l adauga ca fiind prima celula a fiecarei liste indexate cu i.
    for(i = 0; i < nr_noduri; i++) { 
        fscanf(f_in, "%s ", noduri);

        ATNode NewNode = malloc(sizeof(TNode));
        NewNode->next = NULL;
        strcpy(NewNode->v, noduri);
        NewNode->index = i;
        graph->adl[i] = NewNode;
    }

    //Ordonez nodurile
    for(i = 0; i < nr_noduri - 1 ; i++) {
        for(j = i + 1; j < nr_noduri; j++) {
            if(strcmp(graph->adl[i]->v, graph->adl[j]->v) > 0) {
                aux = graph->adl[i];
                graph->adl[i] = graph->adl[j];
                graph->adl[j] = aux;
            }
        }
    }

    for(i = 0; i < nr_arce; i++) {
        fscanf(f_in, "%s %s\n", s1, s2);

        ATNode NewNode = malloc(sizeof(TNode));
        NewNode->next = NULL;
        strcpy(NewNode->v, s2);

        int idx = 0;
        while(strcmp(graph->adl[idx]->v, s2) != 0) {
            idx++;
        }
        NewNode->index = idx;

        j = 0;
        while(strcmp(graph->adl[j]->v, s1) != 0) {
            j++;
        } 
        prev = graph->adl[j];
        aux = graph->adl[j]->next;
        while((aux != NULL) && (strcmp(aux->v, NewNode->v) < 0)) {
            prev = aux;
            aux = aux->next;
        }
        prev->next = NewNode;
        NewNode->next = aux;   
    }

    //Sterg prima celula din fiecare lista de adiacenta
    for(i = 0; i < nr_noduri; i++) {
        ATNode p = graph->adl[i];
        graph->adl[i] = graph->adl[i]->next;
        free(p);
    }

    if(Ciclic(graph) == 0) {
        fprintf(f_out, "corect\n");
    }
    else {
        fprintf(f_out, "imposibil\n");
    }

    //AFISAREA LISTELOR DE ADIACENTA
    
    for(i = 0; i < nr_noduri; i++){
        ATNode aux = graph->adl[i];
        int j;
        while(aux != NULL) {
            printf("%s ", aux->v);
            aux = aux->next;
        }
        printf("NULL\n");
    }

    ATNode k;
    for(i = 0 ; i < nr_noduri ; i++) {
		aux = graph->adl[i];
		
		while(aux != NULL) {
			k = aux;
			aux = aux->next;
			free(k);
		}
		
	}
	free(graph->adl);
	free(graph);
    
    fclose(f_in);
    fclose(f_out);

    return 0;
}